"""Job execution engine — the transport-pluggable seam.

`run_job(connector, job) -> JobOutcome` is a pure engine: it neither
claims work nor disposes of results. A *transport* is whatever obtains
a `Job` and disposes of the outcome — today the local CLI (local.py);
later the job-protocol runner maps the same outcome onto the wire
calls it mirrors (`complete` / `fail` / `defer`, job spec §6.4-§6.6)
without touching connector code. Leases, claims, and heartbeats are
deliberately absent: they belong to that future transport.

All-or-nothing (S-6) lives here: introspection is one call; any
exception fails the whole job and nothing is emitted. Quota maps to a
deferral, not a failure (J-5).
"""

import logging
import traceback
import uuid
from dataclasses import dataclass, field

from connectors.sdk.connector import Connector
from connectors.sdk.emission import EmittedSnapshot, config_problems, emit_snapshot
from connectors.sdk.errors import ConnectorError, GuardrailViolation, QuotaExceeded
from connectors.sdk.providers import (
    ExecuteRequest,
    ExecuteResult,
    Guardrails,
    Identity,
    IntrospectionResult,
    PublishRequest,
    PublishResult,
)
from connectors.sdk.redact import redact_deep, redact_text

logger = logging.getLogger("connectors.sdk.runner")


@dataclass(frozen=True)
class Job:
    """The slice of the §4.1 job record the engine needs.

    `credentials` carries vault references only (J-4); resolution is a
    transport/runner concern and is not wired until a connector needs
    it (task 1.2 live mode).
    """

    job_id: str
    config: dict
    type: str = "snapshot"
    credentials: tuple = ()
    # `execute` payload members (capability §6); unused by `snapshot`.
    request: dict | None = None
    guardrails: dict | None = None
    identity: dict | None = None
    # `publish` payload members (capability §8.2); unused elsewhere.
    artifact: dict | None = None
    target: str | None = None
    # Two-call contract members for `create_report: api` adapters
    # (capability §8.2 amendment / report-authoring §7); absent for
    # template-link publishes.
    mode: str | None = None
    results: dict | None = None
    previous: dict | None = None
    attestation: dict | None = None

    @classmethod
    def local(cls, config: dict) -> "Job":
        return cls(job_id=f"local-{uuid.uuid4().hex}", config=config)


@dataclass(frozen=True)
class JobError:
    code: str
    message: str
    retryable: bool
    detail: dict = field(default_factory=dict)


@dataclass(frozen=True)
class JobOutcome:
    """Mirrors the three terminal wire calls: complete / fail / defer.

    succeeded → `snapshot` set; failed → `error` set; deferred →
    `retry_after_s` set and `error` carries the §6.6 reason.
    """

    status: str  # "succeeded" | "failed" | "deferred"
    snapshot: EmittedSnapshot | None = None
    error: JobError | None = None
    retry_after_s: int | None = None
    # Set instead of `snapshot` when an interactive capability succeeds;
    # delivered inline as the §6.4 `result` envelope.
    result: dict | None = None


def _job_error(code: str, message: str, retryable: bool, detail: dict | None = None) -> JobError:
    """Build a JobError with credential-shaped strings scrubbed from the
    message and detail (job §7 / review F3 / D-66 point 2): a driver
    exception that echoes a resolved DSN must not travel the `fail` wire
    call into `jobs.error` / `health_events.detail`."""
    return JobError(code, redact_text(message), retryable, redact_deep(dict(detail or {})))


def _failed(exc: ConnectorError) -> JobOutcome:
    return JobOutcome(
        status="failed",
        error=_job_error(exc.code, str(exc), exc.retryable, dict(exc.detail)),
    )


def run_job(connector: Connector, job: Job, *, captured_at: str | None = None) -> JobOutcome:
    """Execute one job, dispatched by type."""
    if job.type == "execute":
        return _run_execute(connector, job)
    if job.type == "publish":
        return _run_publish(connector, job)
    if job.type == "test_connection":
        return _run_test_connection(connector, job)
    if job.type != "snapshot":
        raise ValueError(f"no engine for job type {job.type!r} in this SDK version")

    manifest = connector.manifest
    if "metadata" not in connector.handlers:
        return JobOutcome(
            status="failed",
            error=_job_error(
                "config_error",
                f"connector {manifest.name!r} does not declare the metadata capability",
                retryable=False,
            ),
        )
    problems = config_problems(manifest, job.config)
    if problems:
        return JobOutcome(
            status="failed",
            error=_job_error(
                "config_error",
                "config rejected: " + "; ".join(problems),
                retryable=False,
                detail={"errors": problems},
            ),
        )

    provider = connector.handlers["metadata"]
    logger.info(
        "job %s: introspecting system=%s mode=%s connector=%s@%s",
        job.job_id, job.config["system"], job.config["mode"],
        manifest.name, manifest.version,
    )
    try:
        result = provider.introspect(job.config)
        if not isinstance(result, IntrospectionResult):
            raise TypeError(
                f"introspect must return IntrospectionResult, got {type(result).__name__}"
            )
        emitted = emit_snapshot(
            manifest=manifest, config=job.config, result=result, captured_at=captured_at
        )
    except QuotaExceeded as exc:
        logger.info("job %s: deferred %ss (%s)", job.job_id, exc.retry_after_s, exc)
        return JobOutcome(
            status="deferred",
            error=_job_error(exc.code, str(exc), retryable=True, detail=dict(exc.detail)),
            retry_after_s=exc.retry_after_s,
        )
    except ConnectorError as exc:
        # scrub the log line too: a driver error can echo the resolved DSN (F3)
        logger.warning("job %s: failed %s (%s)", job.job_id, exc.code, redact_text(str(exc)))
        return _failed(exc)
    except Exception as exc:  # bare crash → `internal` (job spec §6.7)
        logger.warning("job %s: failed internal (%s)", job.job_id, redact_text(repr(exc)))
        return JobOutcome(
            status="failed",
            error=_job_error(
                "internal",
                f"{type(exc).__name__}: {exc}",
                retryable=True,
                detail={"traceback": traceback.format_exc()},
            ),
        )

    logger.info(
        "job %s: emitted %d objects for system=%s",
        job.job_id, len(emitted.document["objects"]), emitted.document["system"],
    )
    return JobOutcome(status="succeeded", snapshot=emitted)


#: Capability → the handler method the builtin probe calls for it. Every
#: entry names a preflight surface that already existed for another
#: reason; the probe introduces no credential path of its own — each
#: handler resolves exactly what its real work resolves.
PROBED_CAPABILITIES = ("metadata", "query", "publish")


def _probe_config_problems(manifest, config: object) -> list[str]:
    """The config gate, for a probe rather than a snapshot.

    Same schema validation `config_problems` runs, minus its snapshot-
    only `mode` requirement — a publish-only adapter has no metadata
    mode and refusing it for the lack of one would be a lie about the
    config. When the connector *does* declare metadata modes, the mode
    is checked exactly as the snapshot engine checks it.
    """
    if not isinstance(config, dict):
        return ["config must be a JSON object"]
    if manifest.metadata_modes():
        return config_problems(manifest, config)
    problems = [
        p
        for p in config_problems(manifest, config)
        if "'mode' must be one of the manifest's declared metadata" not in p
    ]
    return problems


def _run_test_connection(connector: Connector, job: Job) -> JobOutcome:
    """The builtin health probe (job §4.2 `test_connection`, capability
    §3 `health_probe: builtin`).

    Two rules make this probe worth trusting.

    **It reuses the surfaces that already existed.** Every check below
    is something the connector already did for another reason — the
    snapshot engine's config gate, the introspection role check that
    runs at the head of every live snapshot job, the G3 execution-role
    wall the runner preflights at startup. Nothing here opens a new way
    to reach a credential; a probe with its own credential path would be
    a second thing to keep honest.

    **It never reports a pass it did not perform.** A capability whose
    handler implements no preflight is listed in `unprobed`, not counted
    as green. The failure this avoids is the one the whole checkpoint
    exists for: a Connections screen showing a healthy tick beside a
    connection nobody has ever successfully used.
    """
    manifest = connector.manifest
    checks: list[dict] = []
    unprobed: list[str] = []

    problems = _probe_config_problems(manifest, job.config)
    if problems:
        return JobOutcome(
            status="failed",
            error=_job_error(
                "config_error",
                "config rejected: " + "; ".join(problems),
                retryable=False,
                detail={
                    "errors": problems,
                    "checks": [{"capability": "config", "status": "fail"}],
                    "capability_code": "config_schema",
                },
            ),
        )
    checks.append({"capability": "config", "status": "pass", "facts": {"schema": "valid"}})

    for capability in PROBED_CAPABILITIES:
        handler = connector.handlers.get(capability)
        if handler is None:
            continue
        try:
            facts = handler.preflight(job.config)
        except QuotaExceeded as exc:
            # A probe that hits quota has proved reachability and
            # authentication — the very things it was asked about. It is
            # a warning, not a verdict, and never a deferral: nobody is
            # waiting behind this to do real work.
            checks.append({
                "capability": capability,
                "status": "warn",
                "message": redact_text(str(exc)),
                "facts": {"probed": True, "quota": True},
            })
            continue
        except ConnectorError as exc:
            checks.append({
                "capability": capability,
                "status": "fail",
                "message": redact_text(str(exc)),
            })
            logger.warning(
                "job %s: probe failed for %s/%s (%s)",
                job.job_id, manifest.name, capability, redact_text(str(exc)),
            )
            return JobOutcome(
                status="failed",
                error=_job_error(
                    exc.code,
                    str(exc),
                    exc.retryable,
                    {**dict(exc.detail), "checks": checks, "capability": capability},
                ),
            )
        except Exception as exc:  # bare crash → `internal` (job §6.7)
            checks.append({"capability": capability, "status": "fail",
                           "message": redact_text(repr(exc))})
            return JobOutcome(
                status="failed",
                error=_job_error(
                    "internal",
                    f"{type(exc).__name__}: {exc}",
                    retryable=True,
                    detail={"traceback": traceback.format_exc(), "checks": checks},
                ),
            )
        facts = facts if isinstance(facts, dict) else {}
        if facts.get("probed") is False:
            unprobed.append(capability)
            checks.append({"capability": capability, "status": "unprobed", **(
                {"message": facts["reason"]} if isinstance(facts.get("reason"), str) else {})})
        else:
            checks.append({"capability": capability, "status": "pass",
                           "facts": redact_deep(facts)})

    logger.info(
        "job %s: probed %s (%d check(s), %d unprobed)",
        job.job_id, manifest.name, len(checks), len(unprobed),
    )
    return JobOutcome(
        status="succeeded",
        result={
            "ok": True,
            "system": job.config.get("system") if isinstance(job.config, dict) else None,
            "connector": {"name": manifest.name, "version": manifest.version},
            "checks": checks,
            # The honesty half (dashboard UI-10, one layer down): which
            # declared capabilities this probe could not exercise.
            "unprobed": unprobed,
        },
    )


def _run_execute(connector: Connector, job: Job) -> JobOutcome:
    """The `execute` engine (capability §6, job class interactive).

    Two properties differ from the snapshot engine and both are
    deliberate:

    - guardrails are parsed through `Guardrails.parse`, which floors
      rather than trusts. An absent or stripped `guardrails` member
      yields the conservative default, never an unbounded run (CC-3);
    - quota is terminal here, not a deferral (QE-4): the caller is
      blocked awaiting this result, so a `defer` would hang them.
    """
    manifest = connector.manifest
    executor = connector.handlers.get("query")
    if executor is None:
        return JobOutcome(
            status="failed",
            error=_job_error(
                "config_error",
                f"connector {manifest.name!r} does not declare the query capability",
                retryable=False,
            ),
        )
    try:
        request = ExecuteRequest.parse(job.request)
    except ValueError as exc:
        return JobOutcome(
            status="failed",
            error=_job_error("config_error", str(exc), retryable=False),
        )

    guardrails = Guardrails.parse(job.guardrails)
    identity = Identity.parse(job.identity)
    logger.info(
        "job %s: executing dialect=%s system=%s row_cap=%d timeout_s=%d subject=%s",
        job.job_id, request.dialect, job.config.get("system"),
        guardrails.row_cap, guardrails.timeout_s, identity.subject,
    )
    try:
        result = executor.execute(job.config, request, guardrails, identity)
        if not isinstance(result, ExecuteResult):
            raise TypeError(
                f"execute must return ExecuteResult, got {type(result).__name__}"
            )
    except QuotaExceeded as exc:
        # QE-4: interactive quota is a terminal guardrail error carrying
        # the retry-after, never the J-5 deferral batch jobs get.
        logger.info("job %s: quota exhausted (%s)", job.job_id, exc)
        return JobOutcome(
            status="failed",
            error=_job_error(
                "guardrail",
                str(exc),
                retryable=False,
                detail={
                    **dict(exc.detail),
                    "capability_code": "quota_exhausted",
                    "retry_after_s": exc.retry_after_s,
                },
            ),
        )
    except GuardrailViolation as exc:
        logger.info("job %s: guardrail %s (%s)", job.job_id, exc.capability_code, exc)
        return _failed(exc)
    except ConnectorError as exc:
        logger.warning("job %s: failed %s (%s)", job.job_id, exc.code, redact_text(str(exc)))
        return _failed(exc)
    except Exception as exc:
        logger.warning("job %s: failed internal (%s)", job.job_id, redact_text(repr(exc)))
        return JobOutcome(
            status="failed",
            error=_job_error(
                "internal",
                f"{type(exc).__name__}: {exc}",
                retryable=True,
                detail={"traceback": traceback.format_exc()},
            ),
        )

    logger.info(
        "job %s: %d rows (truncated=%s) in %dms",
        job.job_id, result.row_count, result.truncated, result.duration_ms,
    )
    try:
        payload = result.to_json()
    except Exception as exc:  # QE-6: our defect, so `internal` (job §6.7)
        # Serialization ran outside the guarded region until D-85, so a
        # value QE-5 could not encode escaped the taxonomy, killed the
        # worker thread, and left the runner to die on delivery. The
        # message carries the exception type only — a value that failed
        # to encode is exactly the value not to put in an error string.
        logger.warning("job %s: result serialization failed (%s)",
                       job.job_id, type(exc).__name__)
        return JobOutcome(
            status="failed",
            error=_job_error(
                "internal",
                f"result serialization failed ({type(exc).__name__})",
                retryable=True,
                detail={"traceback": traceback.format_exc()},
            ),
        )
    return JobOutcome(status="succeeded", result=payload)


def _run_publish(connector: Connector, job: Job) -> JobOutcome:
    """The `publish` engine (capability §8, job class interactive).

    Same interactive posture as `execute` (quota is terminal, never a
    deferral — the caller is blocked on this result), plus two §8.2
    gates the engine owns so no adapter can forget them:

    - `artifact_version` outside the adapter's declared support fails
      with capability code `artifact_version_unsupported` before the
      adapter parses a byte of the artifact;
    - PB-3: a non-`full` result without `pending_human_steps` is an
      adapter contract bug and fails loudly here rather than shipping a
      journey that quietly overstates what happened.
    """
    manifest = connector.manifest
    publisher = connector.handlers.get("publish")
    if publisher is None:
        return JobOutcome(
            status="failed",
            error=_job_error(
                "config_error",
                f"connector {manifest.name!r} does not declare the publish capability",
                retryable=False,
            ),
        )
    try:
        request = PublishRequest.parse(
            job.artifact, job.target, job.mode, job.results, job.previous, job.attestation,
        )
    except ValueError as exc:
        return JobOutcome(
            status="failed",
            error=_job_error("config_error", str(exc), retryable=False),
        )

    supported = getattr(publisher, "SUPPORTED_ARTIFACT_VERSIONS", ("1",))
    if request.artifact_version not in supported:
        return JobOutcome(
            status="failed",
            error=_job_error(
                "config_error",
                f"artifact_version {request.artifact_version!r} unsupported by "
                f"{manifest.name!r} (supports: {', '.join(supported)})",
                retryable=False,
                detail={"capability_code": "artifact_version_unsupported"},
            ),
        )

    identity = Identity.parse(job.identity)
    flags = dict(manifest.capabilities.get("publish", {}))
    logger.info(
        "job %s: publishing artifact=%s target=%s connector=%s@%s subject=%s",
        job.job_id, request.artifact.get("id"), request.target,
        manifest.name, manifest.version, identity.subject,
    )
    try:
        result = publisher.publish(job.config, request, identity, flags)
        if not isinstance(result, PublishResult):
            raise TypeError(
                f"publish must return PublishResult, got {type(result).__name__}"
            )
    except QuotaExceeded as exc:
        logger.info("job %s: quota exhausted (%s)", job.job_id, exc)
        return JobOutcome(
            status="failed",
            error=_job_error(
                "guardrail",
                str(exc),
                retryable=False,
                detail={
                    **dict(exc.detail),
                    "capability_code": "quota_exhausted",
                    "retry_after_s": exc.retry_after_s,
                },
            ),
        )
    except ConnectorError as exc:
        logger.warning("job %s: failed %s (%s)", job.job_id, exc.code, redact_text(str(exc)))
        return _failed(exc)
    except Exception as exc:
        logger.warning("job %s: failed internal (%s)", job.job_id, redact_text(repr(exc)))
        return JobOutcome(
            status="failed",
            error=_job_error(
                "internal",
                f"{type(exc).__name__}: {exc}",
                retryable=True,
                detail={"traceback": traceback.format_exc()},
            ),
        )

    # PB-3, as amended for api adapters (capability §8.2 amendment):
    # template_link/instructions journeys are completed by a HUMAN, so
    # empty steps there means the adapter quietly overstated what
    # happened. deliver_model/attest journeys are completed by the
    # authoring SESSION — empty steps is the expected, honest shape
    # (D-91.1's zero-manual-wiring measure), so the gate does not apply.
    if result.mode in ("template_link", "instructions") and not result.pending_human_steps:
        return JobOutcome(
            status="failed",
            error=_job_error(
                "internal",
                f"adapter returned mode={result.mode!r} without pending_human_steps "
                "(PB-3: mandatory whenever a human completes the journey)",
                retryable=False,
            ),
        )

    logger.info(
        "job %s: published mode=%s created=%d pending_steps=%d",
        job.job_id, result.mode, len(result.created), len(result.pending_human_steps),
    )
    try:
        payload = result.to_json()
    except Exception as exc:  # same isolation as execute (QE-6)
        logger.warning("job %s: result serialization failed (%s)",
                       job.job_id, type(exc).__name__)
        return JobOutcome(
            status="failed",
            error=_job_error(
                "internal",
                f"result serialization failed ({type(exc).__name__})",
                retryable=True,
                detail={"traceback": traceback.format_exc()},
            ),
        )
    return JobOutcome(status="succeeded", result=payload)
